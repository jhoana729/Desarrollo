
package laplantafeliz;

import javax.swing.JOptionPane;

public class LaPlantaFeliz {

  
    public static void main(String[] args) {
        String menu[]={"New Plant","See plants","increase","salir"};
        String code, name, R;
        double size, price;
        Inventario c1=null,c2=null;  
        
           do{
          R=(String)JOptionPane.showInputDialog(null,"Selected","Vivero: \" La Planta Feliz" + "\"",1,null, menu, menu[0]);
          switch(R)
          {
               case "New Plant":
                   code= JOptionPane.showInputDialog("Enter code");
                   name= JOptionPane.showInputDialog("Enter name");
                   size= Double.parseDouble(JOptionPane.showInputDialog("Enter size (cm)"));
                   price= Double.parseDouble(JOptionPane.showInputDialog("Enter price"));
                   c1 = new Inventario(code, name, size, price);
                   
                   /**/
                   code= JOptionPane.showInputDialog("Enter code for plant 2");
                   name= JOptionPane.showInputDialog("Enter name for plant 2");
                   size= Double.parseDouble(JOptionPane.showInputDialog("Enter size (cm) for plant 2"));
                   price= Double.parseDouble(JOptionPane.showInputDialog("Enter price for plant 2"));
                    c2 = new Inventario(code, name, size, price);
                   break;
                   
               case "See plants":  
                   JOptionPane.showMessageDialog(null, c1.toString());
                   JOptionPane.showMessageDialog(null, c2.toString());
                   break;
                   
               case "increase":  
                   if (c1.getPrice()<c2.getPrice()){
                       c1.setPrice(c1.getPrice()*1.2);
                   }
    }
    }while(!R.equals("salir"));
   }}       
         
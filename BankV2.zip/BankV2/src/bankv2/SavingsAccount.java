package bankv2;

public class SavingsAccount {

    private String number;
    private String client;
    private String key;
    private double balance;

    public SavingsAccount(String number, String client, String key) {
        this.number = number;
        this.client = client;
        this.key = key;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public double getBalance() {
        return balance;
    }

    private void setBalance(double balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "SavingsAccount{" + "number=" + number + ", client=" + client + ", balance=" + balance + '}';
    }

    public void Record(double value) {
        balance += value;
    }

    public int Remove(String key, double value) {
        if (getKey().equals(key)) {
            if (getBalance() > value) {
                balance -= value;  //balance = balance - value
                return 1;  //Retiro realizado
            } else {
                return 2; //saldo insuficiente
            }
        } else {
            return 3;  //clave incorrecta
        }
    }

}

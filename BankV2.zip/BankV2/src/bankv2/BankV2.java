package bankv2;

import javax.swing.JOptionPane;

public class BankV2 {

    public static void main(String[] args) {
        //creamos el objeto de tipo gestor, donde vamos a realizas las operaciones...
        GestorSavingsAccount gsa = new GestorSavingsAccount(100);
        //menu principal
        String menu[] = {"Create account", "Remove account", "Record", "Remove", "Update key", "Update client", "Update num", "Check balance", "Check client", "Transfer", "Exit"};
        String id, name, op, key;
        double value;
        SavingsAccount c = null;
        int pos, pos2;
        do {
            op = (String) JOptionPane.showInputDialog(null, "Selected", "Main Menu", 1, null, menu, menu[0]);
            switch (op) {
                case "Create account":
                    id = String.valueOf(((int) (Math.random() * 1000000)));
                    name = JOptionPane.showInputDialog("Enter name");
                    key = JOptionPane.showInputDialog("Enter key");
                    c = new SavingsAccount(id, name, key);
                    if (gsa.Add(c)) {
                        JOptionPane.showMessageDialog(null, "created savings account \n" + c.toString());
                    } else {
                        JOptionPane.showMessageDialog(null, "001:Please countact the administor", "error,0", 0);
                    }

                case "Remove account":
                    id = JOptionPane.showInputDialog("Enter number:");
                    if (gsa.Remove(id)) 
                        JOptionPane.showMessageDialog(null, "Removed savings account \n");
                     else 
                        JOptionPane.showMessageDialog(null, gsa.toString());
                    
                    break;
                case "Print":
                    JOptionPane.showMessageDialog(null, gsa.toString());
                    break;
            }

        } while (!op.equals("exit"));
    }
}

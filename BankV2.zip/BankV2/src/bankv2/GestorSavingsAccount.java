package bankv2;

public class GestorSavingsAccount {

    private int size;
    private int counter;
    private SavingsAccount gestor[];

    public GestorSavingsAccount(int size) {
        this.size = size;
        counter = 0;
        gestor = new SavingsAccount[this.size];
    }

    public boolean Add(SavingsAccount sa) {
        if (counter < size) {
            gestor[counter] = sa;
            counter++;
            return true;
        }
        return false;
    }

    public boolean Remove(String number) {
        //recorremos el vector buscando la cuenta...
        for (int i = 0; i < counter; i++) {
            if (gestor[i].getNumber().equals(number)) {
                //realizamos el cambio
                for (int j = i; j < counter - 1; j++) {
                    gestor[j] = gestor[j + 1];
                }
                gestor[counter] = null;
                counter--;
                return true;
            }
        }
        return false;

    }

    public int Search(String number) {
        int pos = -1;
        for (int i = 0; i < counter; i++) {
            if (gestor[i].getNumber().equals(number)) {
                pos = i;
            }
        }
        return pos;
    }

    @Override
    public String toString() {
        String cts = "";
        for (int i = 0; i < counter; i++) {
            cts = cts + gestor[i].toString() + "\n";
        }
        return cts;
    }

}

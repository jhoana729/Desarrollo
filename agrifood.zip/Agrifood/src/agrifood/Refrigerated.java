package agrifood;

public class Refrigerated extends Product{
    private String date;

    public Refrigerated(String date, int code, String name, double priceB) {
        super(code, name, priceB);
        this.date = date;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Refrigerated Product{" + super.toString()+
                "date=" + date + '}';
    }
    public double CalculePriceV()
    {
        return super.CalculePriceV()+ (code%100)*50;
    }
    
    
    
}


package agrifood;

//abstract -> No se van a crear objetos de esta clase...
public abstract class Product {
    protected int code;
    protected String name;
    protected double priceB;

    public Product(int code, String name, double priceB) {
        this.code = code;
        this.name = name;
        this.priceB = priceB;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPriceB() {
        return priceB;
    }

    public void setPriceB(double priceB) {
        this.priceB = priceB;
    }

    @Override
    public String toString() {
        return "code=" + code + ", name=" + name 
                + ", priceB=" + priceB;
    }
    
    public double CalculePriceV()
    {
        return priceB*1.35;
    }
    
    
}

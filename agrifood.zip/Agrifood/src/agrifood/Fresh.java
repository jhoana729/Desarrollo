
package agrifood;

public class Fresh extends Product{
    //extends-> signigica que hereda de producto...
    private int number;
    private String country;

    public Fresh(int number, String country, int code, String name, double priceB) {
        super(code, name, priceB); //constructor del padre 
        this.number = number;
        this.country = country;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return "Fresh Product{" + super.toString() +
                "number=" + number + ", country=" + country + '}';
    }
    
 
    
    
    
}

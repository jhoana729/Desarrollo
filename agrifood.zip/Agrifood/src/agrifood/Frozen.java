
package agrifood;

public class Frozen extends Product{
    private int temp;

    public Frozen(int temp, int code, String name, double priceB) {
        super(code, name, priceB);
        this.temp = temp;
    }

    public int getTemp() {
        return temp;
    }

    public void setTemp(int temp) {
        this.temp = temp;
    }

    @Override
    public String toString() {
        return "Frozen Product{" 
                + super.toString() + "temp=" + temp + '}';
    }
    
    @Override
    public double CalculePriceV()
    {
        return super.CalculePriceV()+(temp+5)*40;
    }
    
    
}

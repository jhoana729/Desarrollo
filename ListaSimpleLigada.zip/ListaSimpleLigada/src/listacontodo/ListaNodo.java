/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package listacontodo;

import javax.swing.*;
public class ListaNodo 
{
 //atributos
    Nodo cabeza;
    //Constructor
    public ListaNodo()
    {
        cabeza=null;    
    }
    //metodo que inserta un nodo en 
    //la cabeza 
    public void InsertarAdelante(int d)
    {
        Nodo q;
        q= new Nodo(d);
        if(cabeza==null)
        {
            cabeza=q;
        }
        else
        {
            q.asignarliga(cabeza);
            cabeza=q;
        }
    }
    
    
    
    
    //metodo q obtiene la cantidad de nodos en una lista
    public int ContarNodos()
    {
        Nodo p;
        p=cabeza;
        int con=0;
        while(p!=null)
        {
            con=con+1;
            p=p.obtenerliga();
        }
        return con;
    }
    
    
    
    
    
    
    
    
    
    //metodo para mostrar todo los 
    //nodos incluye la direccion el dato 
    //y la liga 
    public String Imprimir()
    {
        Nodo p;
        p=cabeza;
        String resultado="";
        while(p!=null)
        {
            resultado+="Direccion="+
             p + " Dato=" + p.obtenerDato() + 
             " liga=" + p.obtenerliga() + "\n" ;
            p=p.obtenerliga();
        }
        return resultado;
    }
    
 
    
  public int sumaDatos()
  {
        Nodo p;
        p=cabeza;
       int suma=0;
        while(p!=null)
        {
           suma+=p.obtenerDato();
           p=p.obtenerliga();
        }
        return suma;
        
  }
  
  
  
  
  
  
  
  
  
  
  
  
  public void ContPares_Impar()
        {
            Nodo p;
            p=cabeza;
            int con=0;
            int con1=0;
            while(p!=null)
            {
                if(p.obtenerDato()%2==0)
                {
                    con=con+1;
                    
                }
                else
                {
                    con1=con1+1;
                }
                p=p.obtenerliga();
            }
         JOptionPane.showMessageDialog(null,"Pares  : " + con);
         JOptionPane.showMessageDialog(null,"Impares  : " + con1);
        }
    



  public void Promedio()
    {
        Nodo p;
        p=cabeza;
        int suma=0;
        int cont=0;
        float   prom;
       if(p==null)
       {
           System.out.print("lista vacia");
       }
       else
       {
            while(p!=null)
             {
                suma=suma+p.obtenerDato();
                cont= cont +1;
                p=p.obtenerliga();  
             }
       }
      prom = suma / cont;
       JOptionPane.showMessageDialog(null, "El valor del promedio de la lista es "+prom);
              
    }
   
  
   public void InsertarAlFinal(int d)
     {
         Nodo p, q;
         p=cabeza;
         q= new Nodo(d);
         if(cabeza==null)
         {
            cabeza=q;
         }
         else
         {
            while(p.obtenerliga() != null)
            {
                p=p.obtenerliga(); 
            }
            p.asignarliga(q);
            q.asignarliga(null);
         }
     }
  
   
   
   public void BorrarFinal()
   {
         
       Nodo p,ant;
         p=cabeza;
         ant=p;
         if(cabeza==null)
         {
             JOptionPane.showMessageDialog
            (null, "No hay nodos para borrar");
         }
         else
         {
              while(p.obtenerliga()!=null)
              {
                 ant=p;
                 p=p.obtenerliga();
              }  
               ant.asignarliga(null);
         }
     }
     
   
   
   
   
     
      public void BorrarInicio()
      {
         Nodo p;
         p=cabeza;
         if (cabeza==null)
          {
             System.out.print("Lista vacia");
           }
         else
           {
              cabeza= p.obtenerliga();
              p.asignarliga(null);
           }
         } 
      
      
      
      
      
      
      public void BorrarMayores(int num)
      {
          Nodo p,ant,aux;
          p=cabeza;
          ant=p;
          aux=cabeza;

          if (cabeza==null)
             {
             System.out.print("Lista vacia");
             }
          else
             {
                 while(p!=null)
                 {
                    JOptionPane.showMessageDialog(null, p.obtenerDato());
                     if(p.obtenerDato()>num)
                    {
                        if (p==cabeza)
                        {
                            //borrar si el nodo esta al principio
                            BorrarInicio();
                        }
                    
                        else
                        {
                            if (p.obtenerliga()==null)
                            {
                                //borrar si el nodo esta al final
                                BorrarFinal();
                            }
                            else
                            {
                                //borrar si esta el otro lugar
                                
                                ant.asignarliga(p.obtenerliga());
                                aux=p;
                                aux.asignarliga(null);
                                p=ant;

                                
            
                            }
                        } 
                    }
              ant=p;   
              p=p.obtenerliga();
             
             }
         
          
      }  
}
      
      
      public void InsertarPosicion(int d)
      {
          Nodo p,q;
          p=cabeza;
          q=new Nodo(d);
          int pos,con=1;
          pos=Integer.parseInt(JOptionPane.showInputDialog
                 ("Ingrese la posición a insertar"));
          if(p==null)
          {
              System.out.print("Lista vacia");
          }
          else
          {
              while(p!=null)
              {
                if(pos==1)
                {
                   InsertarAdelante(d);
                   break;
                }
                if(pos==ContarNodos()+1)
                {
                    InsertarAlFinal(d);
                    break;
                }
                if(pos>ContarNodos())
                {
                    JOptionPane.showMessageDialog
                    (null, "Posición fuera del tamaño de la lista");
                    break;
                }
                if(con!=pos-1)
                {
                    p=p.obtenerliga();
                    con++;
                }
                else
                {
                    q.asignarliga(p.obtenerliga());
                    p.asignarliga(q);
                    break;
                }
              }
          }
      }
}


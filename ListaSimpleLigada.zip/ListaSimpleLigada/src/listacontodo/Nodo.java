package listacontodo;

public class Nodo 
{
  // ATRIBUTOS DE LA CLASE
  
  private int dato;
  private Nodo liga;		                                                                                       
  
  // CONSTRUCTOR QUE RECIBE EL PARAMETRO DEL DATO        *
  public Nodo(int d)
  {
      dato=d;
      liga =null;
  }
  
  // METODOS OBTENER QUE REGRESAN EL VALOR DE UN ATRIBUTO           *

  public int obtenerDato()
  {
      return dato;
  }
  public Nodo obtenerliga()
  {
      return liga;
  }
 
  // METODO QUE ASIGNAN UN NUEVO VALOR AL ATRIBUTO*
  public void asignarDato(int d)
  {
	 dato=d;
  }  
public void asignarliga(Nodo l)
  {
	 liga=l;
  }   
  
}


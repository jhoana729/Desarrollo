/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package listacontodo;

import javax.swing.*;
public class Principal 
{
    public static void main(String[] args) 
    {
        ListaNodo lista=new ListaNodo();
        int opcion;
        int valor=0;
       do
       {
            opcion=Integer.parseInt
            (JOptionPane.showInputDialog
            ("Menu de opciones\n"+
             "1. Insertar al inicio\n"+
             "2. Insertar al final\n"+
             "3. Promedio \n"+
             "4. Imprimir lista \n"+
             "5. Borrar al inicio \n"+
             "6. Borrar al final \n"+
             "7. Cantidad de nodos\n"+
             "8. Suma de datos par/Impar \n"+
             "9. Borrar elementos mayores\n"+
             "10. Suma total de nodos \n"+
             "11. salir"));
              
               switch(opcion)
               {  
                case 1:
                       valor=Integer.parseInt
                        (JOptionPane.showInputDialog
                        ("Digita el valor a insertar"));
                       lista.InsertarAdelante(valor);
                       break;
                case 2:
                        valor=Integer.parseInt
                         (JOptionPane.showInputDialog
                        ("Da el valor a insertar"));
                        lista.InsertarAlFinal(valor);
                        break;
                case 3:
                        lista.Promedio();
                        break;        
                case 4:
                        JOptionPane.showMessageDialog(null,lista.Imprimir());
                        break;
                        
                        
                        
                        
                        
                        
                        
                case 5:
                        lista.BorrarInicio();
                        JOptionPane.showMessageDialog(null,"El nodo a sido borrado ");
                        break;
                case 6:
                        lista.BorrarFinal();
                        JOptionPane.showMessageDialog(null,"El nodo a sido borrado ");
                        break;
                case 7:
                        JOptionPane.showMessageDialog(null,"Cantidad de nodos: "+lista.ContarNodos());
                        break;
                case 8:
                        lista.ContPares_Impar();
                        break;
                case 9:
                        int numero=Integer.parseInt(JOptionPane.showInputDialog("Digite el número: "));
                        lista.BorrarMayores(numero);
	                break;
                case 10:
                        JOptionPane.showMessageDialog(null,"La suma de los datos es : "+lista.sumaDatos());
	       break;
     }//fin case
       }while(opcion!=11);
     }// fin main
}//fin clase

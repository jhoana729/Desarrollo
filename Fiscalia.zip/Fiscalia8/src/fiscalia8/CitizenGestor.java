
package fiscalia8;

public class CitizenGestor {
    private int size;
    private int counter;
    private Citizen vector[];

    public CitizenGestor(int size) {
        this.size = size;
        counter=0;
        vector= new Citizen[size];
    }
    
    public boolean Add(Citizen c)
    {
        if(counter<size)
        {
            vector[counter]=c;
            counter++;
            return true;
        }
        return false;
    }
    
    public Citizen Search(String id)
    {
        for (int i = 0; i < counter; i++) {
            if(vector[i].getId().equals(id))
                return vector[i];
        }
        return null; //No se encuentra ese ciudadano
    }
    
    public Citizen SearchName(String name)
    {
        for (int i = 0; i < counter; i++) {
            if(vector[i].getName().equals(name))
                return vector[i];
        }
        return null; //No se encuentra ese ciudadano
    }
    
}


package fiscalia8;
import java.util.Date;
public class ComplaintGestor {
    private int size;
    private int counter;
    private Complaint vector[];

    public ComplaintGestor(int size) {
        this.size = size;
        counter=0;
        vector= new Complaint[size];
    }
    
    public boolean Add(Complaint c)
    {
        if(counter<size)
        {
            vector[counter]=c;
            counter++;
            return true;
        }
        return false;
    }
    
    public Complaint Search(String code)
    {
        for (int i = 0; i < counter; i++) {
            if(vector[i].getCode().equals(code))
                return vector[i];
        }
        return null; //No se encuentra ese ciudadano
    }
    
    public Complaint[] SearchCitizen(String id)
    {
        int N=AmountC(id);
        Complaint cit[] = new Complaint[N];
        int ccounter=0;
        for (int i = 0; i < this.counter; i++) {
            if(vector[i].getWhistleblower().getId().equals(id) ||
                    vector[i].getDenounce().getId().equals(id))
            {
                cit[ccounter]=vector[i];
                ccounter++;
            }
        }
        return cit;
    }
    
    //Determina la cantidad de veces que aparece un ciudadadono
    //como denunciante o denunciado
    public int AmountC(String id)
    {
        int ccounter=0;
        for (int i = 0; i < this.counter; i++) {
            if(vector[i].getWhistleblower().getId().equals(id) ||
                    vector[i].getDenounce().getId().equals(id))
            {
                ccounter++;
            }
        }
        return ccounter;
    }
    
    
    public Complaint[] SearchType(String type)
    {
        int N=AmountType(type);
        Complaint cit[] = new Complaint[N];
        int ccounter=0;
        for (int i = 0; i < this.counter; i++) {
            if(vector[i].getType().equals(type))
            {
                cit[ccounter]=vector[i];
                ccounter++;
            }
        }
        return cit;
    }
    
    public int AmountType(String type)
    {
        int ccounter=0;
        for (int i = 0; i < this.counter; i++) {
            if(vector[i].getType().equals(type))
            {
                ccounter++;
            }
        }
        return ccounter;
    }
    
    public double CalculePorcentage(String type)
    {
        int amount=0;
        for (int i = 0; i < counter; i++) {
            if(vector[i].getType().equals(type))
                amount++;
        }
        return amount/(double)counter*100;
    }
    
    //La clase date de java tiene los meses así: 0-enero, 1-Febrero, 2 - Marzo
    public int CalculeAmountMounth(int mounth)
    {
        int amount=0;
        for (int i = 0; i < counter; i++) {
            if(vector[i].getDate().getMonth()== mounth-1)
                amount++;
        }
        return amount;
    }
    
    public int CalculeAmount(Date date)
    { Date d;
        int amount=0;
        for (int i = 0; i < counter; i++) {
            if(vector[i].getDate().equals(date))
                amount++;
        }
        return amount;
    }

    public int getCounter() {
        return counter;
    }
    
    
}
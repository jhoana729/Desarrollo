package fiscalia8;
import java.util.Date;

public class Complaint {
    private String code;
    private Citizen whistleblower;  //denunciante
    private String type;
    private Date date;   //fecha del suceso
    private Date dateComplaint; //fecha de la denuncia 
    private Citizen denounce;  //denunciado
    private String description;

    public Complaint(String code, Citizen whistleblower, String type, Date date, Date dateComplaint, Citizen denounce, String description) {
        this.code = code;
        this.whistleblower = whistleblower;
        this.type = type;
        this.date = date;
        this.dateComplaint = dateComplaint;
        this.denounce = denounce;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Citizen getWhistleblower() {
        return whistleblower;
    }

    public void setWhistleblower(Citizen whistleblower) {
        this.whistleblower = whistleblower;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Date getDateComplaint() {
        return dateComplaint;
    }

    public void setDateComplaint(Date dateComplaint) {
        this.dateComplaint = dateComplaint;
    }

    public Citizen getDenounce() {
        return denounce;
    }

    public void setDenounce(Citizen denounce) {
        this.denounce = denounce;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    
    
}
